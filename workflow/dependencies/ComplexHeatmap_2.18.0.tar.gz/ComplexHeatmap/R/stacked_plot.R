
# stacked_simple = function(..., name, which = c("row", "column")) {
# 	which = match.arg(which)
# 	arg_list = list()
# 	arg_list$which = which
# 	arg_list[[name]] = anno_simple(..., which = which)
# 	do.call("HeatmapAnnotation", arg_list)
# }
# stacked_points
# stacked_lines
# stacked_image
# stacked_text
# stacked_barplot
# stacked_boxplot
# stacked_histogram
# stacked_joyplot
# stacked_horizon


# draw
