library(testthat)
library(TFBSTools)

test_check("TFBSTools")
